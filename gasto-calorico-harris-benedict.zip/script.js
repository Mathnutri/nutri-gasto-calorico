
document.getElementById("calc-form").addEventListener("submit", function(e) {
    e.preventDefault();

    const sexo = document.getElementById("sexo").value;
    const idade = parseInt(document.getElementById("idade").value);
    const peso = parseFloat(document.getElementById("peso").value);
    const altura = parseFloat(document.getElementById("altura").value);
    const fatorAtividade = parseFloat(document.getElementById("atividade").value);
    const objetivo = document.getElementById("objetivo").value;

    let GEB;
    if (sexo === "masculino") {
        GEB = 66.5 + (13.75 * peso) + (5.003 * altura) - (6.75 * idade);
    } else {
        GEB = 655.1 + (9.563 * peso) + (1.850 * altura) - (4.676 * idade);
    }

    const GET = GEB * fatorAtividade;

    let dica = "";
    switch(objetivo) {
        case "gordura":
            dica = "Consistência é mais importante que velocidade!";
            break;
        case "perda10kg":
            dica = "Com planejamento e foco, você chega lá!";
            break;
        case "performance":
            dica = "Alimentação é o combustível da performance!";
            break;
        case "massa":
            dica = "Músculo se constrói com treino e boa nutrição!";
            break;
        case "tratamento":
            dica = "A nutrição é sua aliada na saúde!";
            break;
    }

    document.getElementById("resultado").innerHTML = `
        <h2>Resultado</h2>
        <p><strong>Gasto Energético Basal (GEB):</strong> ${GEB.toFixed(2)} kcal</p>
        <p><strong>Gasto Energético Total (GET):</strong> ${GET.toFixed(2)} kcal</p>
        <h3>💡 Dica do nutri Matheus Henrique pra você!</h3>
        <p>${dica}</p>
    `;
});
